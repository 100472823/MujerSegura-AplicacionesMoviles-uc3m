package com.aplicacionesmoviles.uc3m.grupo3.MujerSegura.ui.Hospitales;

public class MyLocation {
public static double latitud;
    public static double longitud;

    public MyLocation(double lat, double longitud) {
        this.latitud= lat;
        this.longitud = longitud;

    }

    public static double getLatitud() {
        return latitud;
    }

    public static double getLongitud() {
        return longitud;
    }
}
