package com.aplicacionesmoviles.uc3m.grupo3.MujerSegura;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Menu;

import com.aplicacionesmoviles.uc3m.grupo3.MujerSegura.ui.Hospitales.MapsActivity_Near_Hospitals;
import com.aplicacionesmoviles.uc3m.grupo3.MujerSegura.ui.Hospitales.MyLocation;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.navigation.NavigationView;

import androidx.core.app.ActivityCompat;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;
import android.net.Uri;
import android.content.Intent;
import android.telephony.SmsManager;
import android.app.PendingIntent;
import android.widget.Button;
import android.widget.EditText;
import android.telephony.SmsManager;
import android.Manifest;

import com.aplicacionesmoviles.uc3m.grupo3.MujerSegura.databinding.ActivityMainBinding;
import com.aplicacionesmoviles.uc3m.grupo3.MujerSegura.ui.Hospitales.MyLocation;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;

public class MainActivity extends AppCompatActivity {

    private AppBarConfiguration mAppBarConfiguration;

    private static final String TAG = "MainActivity";

    private static final int PERMISSION_REQUEST_CALL_PHONE = 1;

    public Location ObtenerUbicacionActual() {
        LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        String provider = LocationManager.GPS_PROVIDER;

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            return null;
        }
        return locationManager.getLastKnownLocation(provider);
    }

    public void funcion_boton_violeta(View view) {

        // LEER NÚMEROS DEL FICHERO CON LAS PREFERENCIAS

        String guardarPreferenciasFile = "com.aplicacionesmoviles.uc3m.grupo3.MujerSegura.ui.SettingsFile";
        SharedPreferences preferencias = getSharedPreferences(guardarPreferenciasFile,MODE_PRIVATE);

        String personal_number = preferencias.getString("NUMERO_PERSONAL", "");
        String emergency_number1 = preferencias.getString("NUMERO_EMERGENCIA1", "");
        String emergency_number2 = preferencias.getString("NUMERO_EMERGENCIA2", "");
        String user_name = preferencias.getString("NOMBRE_USUARIO", "");

        // MANDAR SMS

        // Obtener la ubicación actual y una url que diriga a google maps en esa ubicación

        Location ubicacion_actual = ObtenerUbicacionActual();
        double latitud = ubicacion_actual.getLatitude();
        double longitud = ubicacion_actual.getLongitude();
        @SuppressLint("DefaultLocale") String ubicacion_url = String.format("https://www.google.com/maps?q=%f,%f", latitud, longitud);

        String message1 = user_name + " está en peligro y necesita tu ayuda!";

        String message2 = "Su última ubicación: " + ubicacion_url;

        System.out.println(ubicacion_url);

        System.out.println(user_name + " con número: " + personal_number + " está en peligro y necesita tu ayuda! Su última ubicación: latitud-> " + latitud + " longitud-> " + longitud);

        SmsManager smsManager = SmsManager.getDefault();

        smsManager.sendTextMessage(emergency_number1, null, message1, null, null);
        smsManager.sendTextMessage(emergency_number1, null, message2, null, null);
        smsManager.sendTextMessage(emergency_number2, null, message1, null, null);
        smsManager.sendTextMessage(emergency_number2, null, message2, null, null);

        // LLAMAR

        Snackbar.make(view, "Llamando a la policía", Snackbar.LENGTH_LONG).show();
        String policeNumber = "112";
        Intent callIntent = new Intent(Intent.ACTION_CALL);
        callIntent.setData(Uri.parse("tel:" + policeNumber));
        if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            // Si no se tiene el permiso, solicitarlo
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.CALL_PHONE}, PERMISSION_REQUEST_CALL_PHONE);
        } else {
            // Si se tiene el permiso, iniciar la llamada
            startActivity(callIntent);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        com.aplicacionesmoviles.uc3m.grupo3.MujerSegura.databinding.ActivityMainBinding binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        setSupportActionBar(binding.appBarMain.toolbar);

        if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.SEND_SMS}, 1);
        }

        binding.appBarMain.fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                funcion_boton_violeta(view);
            }
        });

        DrawerLayout drawer = binding.drawerLayout;
        NavigationView navigationView = binding.navView;
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_home, R.id.nav_gallery, R.id.nav_slideshow, R.id.nav_Hospitales)
                .setOpenableLayout(drawer)
                .build();

        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }
}