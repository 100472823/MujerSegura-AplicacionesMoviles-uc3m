package com.aplicacionesmoviles.uc3m.grupo3.MujerSegura.ui.Settings;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.MainThread;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.aplicacionesmoviles.uc3m.grupo3.MujerSegura.R;
import com.aplicacionesmoviles.uc3m.grupo3.MujerSegura.databinding.FragmentSettingsBinding;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

public class Preferencias extends AppCompatActivity {

    public void guardarPreferencias(View view) {
        Snackbar.make(view, "Guardando los datos", Snackbar.LENGTH_LONG).show();

        String guardarPreferenciasFile = "com.aplicacionesmoviles.uc3m.grupo3.MujerSegura.ui.SettingsFile";

        SharedPreferences preferencias = getSharedPreferences(
                guardarPreferenciasFile,
                Context.MODE_PRIVATE
        );

        SharedPreferences.Editor editor = preferencias.edit();

        EditText emergency_number1 = findViewById(R.id.editTextPhoneContacto1);
        EditText emergency_number2 = findViewById(R.id.editTextPhoneContacto2);
        EditText personal_number = findViewById(R.id.editTextPhone);
        EditText user_name = findViewById(R.id.editTextNameAddress);
        EditText emergency_name1 = findViewById(R.id.editTextContacto1);
        EditText emergency_name2 = findViewById(R.id.editTextContacto2);

        editor.putString("NUMERO_PERSONAL", personal_number.getText().toString());
        editor.putString("NUMERO_EMERGENCIA1", emergency_number1.getText().toString());
        editor.putString("NUMERO_EMERGENCIA2", emergency_number2.getText().toString());
        editor.putString("NOMBRE_USUARIO", user_name.getText().toString());
        editor.putString("NOMBRE_EMERGENCIA1", emergency_name1.getText().toString());
        editor.putString("NOMBRE_EMERGENCIA2", emergency_name2.getText().toString());

        editor.apply();
    }


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_settings);

        Button buttonGuardar = findViewById(R.id.button3);
        buttonGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                guardarPreferencias(v);
            }
        });
    }
}
