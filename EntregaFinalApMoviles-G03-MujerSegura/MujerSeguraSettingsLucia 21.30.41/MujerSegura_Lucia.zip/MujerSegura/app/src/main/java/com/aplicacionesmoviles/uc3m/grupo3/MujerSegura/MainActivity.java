package com.aplicacionesmoviles.uc3m.grupo3.MujerSegura;

import android.content.Context;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Menu;

import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.navigation.NavigationView;

import androidx.core.app.ActivityCompat;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;
import android.net.Uri;
import android.content.Intent;
import android.telephony.SmsManager;
import android.app.PendingIntent;
import android.widget.Button;
import android.widget.EditText;
import android.telephony.SmsManager;
import android.Manifest;

import com.aplicacionesmoviles.uc3m.grupo3.MujerSegura.databinding.ActivityMainBinding;

import java.io.FileOutputStream;

public class MainActivity extends AppCompatActivity {

    private AppBarConfiguration mAppBarConfiguration;

    private static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        com.aplicacionesmoviles.uc3m.grupo3.MujerSegura.databinding.ActivityMainBinding binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        setSupportActionBar(binding.appBarMain.toolbar);

        //EditText emergency_number1, emergency_number2;
        //emergency_number1 = findViewById(R.id.editTextPhoneContacto1);
        //emergency_number2 = findViewById(R.id.editTextPhoneContacto2);

        if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.SEND_SMS}, 1);
        }

        binding.appBarMain.fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String message = "¡Ayuda, estoy en peligro!";

                SmsManager smsManager = SmsManager.getDefault();

                String numero_prueba = "620704527";
                smsManager.sendTextMessage(numero_prueba, null, message, null, null);

                //smsManager.sendTextMessage(emergency_number1.getText().toString(), null, message, null, null);
                //smsManager.sendTextMessage(emergency_number2.getText().toString(), null, message, null, null);


                Snackbar.make(view, "Llamando a la policía", Snackbar.LENGTH_LONG).show();
                String policeNumber = "112";
                Uri number = Uri.parse("tel:" + policeNumber);
                Intent dial = new Intent(Intent.ACTION_DIAL, number);
                startActivity(dial);
            }
        });

        DrawerLayout drawer = binding.drawerLayout;
        NavigationView navigationView = binding.navView;
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_home, R.id.nav_gallery, R.id.nav_slideshow, R.id.nav_Hospitales)
                .setOpenableLayout(drawer)
                .build();



        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);
    }

    public void guardarDatos(View view) {

        // Obtenemos referencias de los botones y de los edit text donde se escriben los datos

        EditText emergency_number1_txt = (EditText) findViewById(R.id.editTextPhoneContacto1);
        EditText emergency_number2_txt = (EditText) findViewById(R.id.editTextPhoneContacto2);
        EditText personal_number_txt = (EditText) findViewById(R.id.editTextPhone);
        Button guardarDatosBoton = (Button) findViewById(R.id.button3);

        String emergency_number1 = emergency_number1_txt.getText().toString();
        String emergency_number2 = emergency_number2_txt.getText().toString();
        String personal_number = personal_number_txt.getText().toString();

        // Creamos y abrimos un fichero

        String filename = "agenda_interna";
        FileOutputStream outputStream;

        // Escribimos en el fichero

        try {
            outputStream = openFileOutput(filename, Context.MODE_PRIVATE);
            outputStream.write(emergency_number1.getBytes());
            outputStream.write(emergency_number2.getBytes());
            outputStream.write(personal_number.getBytes());
            outputStream.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        // Creamos un Intent que lamará a la segunda actividad y la iniciamos

        //Intent intent = new Intent (this, SecondActivity.class);
        //startActivity(intent);
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }
}