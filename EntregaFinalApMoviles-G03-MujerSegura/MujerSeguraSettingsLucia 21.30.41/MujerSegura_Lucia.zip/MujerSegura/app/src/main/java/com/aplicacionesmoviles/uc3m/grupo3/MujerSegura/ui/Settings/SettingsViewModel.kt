package com.aplicacionesmoviles.uc3m.grupo3.MujerSegura.ui.Settings

import androidx.lifecycle.ViewModel

class SettingsViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}